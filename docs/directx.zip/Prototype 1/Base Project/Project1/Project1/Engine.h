#pragma once
#include "WindowContainer.h"
#include "Timer.h"
#include <DirectXMath.h>
class Engine : WindowContainer
{
public:
	bool Initialize(HINSTANCE hInstance, std::string window_title, std::string window_class, int width, int height);
	bool ProcessMessages();
	void Update();
	void RenderFrame();

	bool BoundingBox(XMVECTOR& firstObjMin,
		XMVECTOR& firstObjMax,
		XMMATRIX& firstObjWorldSpace,
		XMVECTOR& secondObjMin,
		XMVECTOR& secondObjMax,
		XMMATRIX& secondObjWorldSpace);

private:
	Timer timer;
};