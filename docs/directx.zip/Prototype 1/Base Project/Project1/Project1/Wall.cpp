#include "Wall.h"

Wall::~Wall()
{

}


bool Wall::Init(ID3D11Device* device, ID3D11DeviceContext* deviceContext, ID3D11ShaderResourceView* texture, ConstantBuffer<CB_VS_vertexshader>& cb_vs_vertexshader)
{
	this->device = device;
	this->deviceContext = deviceContext;
	this->texture = texture;
	this->cb_vs_vertexshader = &cb_vs_vertexshader;

	//Textured Square
	Vertex v[] =
	{
		Vertex(-10.0f,  -6.0f, -1.0f, 0.0f, 1.0f), //FRONT Bottom Left   - [0]
		Vertex(-10.0f,   6.0f, -1.0f, 0.0f, 0.0f), //FRONT Top Left      - [1]
		Vertex(10.0f,   6.0f, -1.0f, 1.0f, 0.0f), //FRONT Top Right     - [2]
		Vertex(10.0f,  -6.0f, -1.0f, 1.0f, 1.0f), //FRONT Bottom Right   - [3]
		Vertex(-10.0f,  -6.0f, 1.0f, 0.0f, 1.0f), //BACK Bottom Left   - [4]
		Vertex(-10.0f,   6.0f, 1.0f, 0.0f, 0.0f), //BACK Top Left      - [5]
		Vertex(10.0f,   6.0f, 1.0f, 1.0f, 0.0f), //BACK Top Right     - [6]
		Vertex(10.0f,  -6.0f, 1.0f, 1.0f, 1.0f), //BACK Bottom Right   - [7]
	};

	//Load Vertex Data
	HRESULT hr = vertexBuffer.Init(this->device, v, ARRAYSIZE(v));
	if (FAILED(hr))
	{
		return false;
	}

	DWORD indices[] =
	{
		0, 1, 2, //FRONT
		0, 2, 3, //FRONT
		4, 7, 6, //BACK 
		4, 6, 5, //BACK
		3, 2, 6, //RIGHT SIDE
		3, 6, 7, //RIGHT SIDE
		4, 5, 1, //LEFT SIDE
		4, 1, 0, //LEFT SIDE
		1, 5, 6, //TOP
		1, 6, 2, //TOP
		0, 3, 7, //BOTTOM
		0, 7, 4, //BOTTOM
	};

	//Load Index Data
	hr = indexBuffer.Init(this->device, indices, ARRAYSIZE(indices));
	if (FAILED(hr))
	{
		return false;
	}

	SetPosition(0.0f, 0.0f, 0.0f);
	SetRotation(0.0f, 0.0f, 0.0f);
	UpdateWorldMatrix();

	return true;
}




void Wall::SetTexture(ID3D11ShaderResourceView* texture)
{
	this->texture = texture;
}

void Wall::Draw(const XMMATRIX& viewProjectionMatrix)
{
	cb_vs_vertexshader->data.mat = worldMatrix * viewProjectionMatrix;
	cb_vs_vertexshader->data.mat = XMMatrixTranspose(cb_vs_vertexshader->data.mat);
	cb_vs_vertexshader->ApplyChanges();
	deviceContext->VSSetConstantBuffers(0, 1, cb_vs_vertexshader->GetAddressOf());

	deviceContext->PSSetShaderResources(0, 1, &texture);
	deviceContext->IASetIndexBuffer(indexBuffer.Get(), DXGI_FORMAT::DXGI_FORMAT_R32_UINT, 0);
	UINT offset = 0;
	deviceContext->IASetVertexBuffers(0, 1, vertexBuffer.GetAddressOf(), vertexBuffer.StridePtr(), &offset);
	deviceContext->DrawIndexed(indexBuffer.BufferSize(), 0, 0);
}



void Wall::UpdateWorldMatrix()
{
	worldMatrix = XMMatrixRotationRollPitchYaw(rot.x, rot.y, rot.z) * XMMatrixTranslation(pos.x, pos.y, pos.z); 
	XMMATRIX vecRotationMatrix = XMMatrixRotationRollPitchYaw(0.0f, rot.y, 0.0f);
	vec_forward = XMVector3TransformCoord(DEFAULT_FORWARD_VECTOR, vecRotationMatrix);
	vec_backward = XMVector3TransformCoord(DEFAULT_BACKWARD_VECTOR, vecRotationMatrix);
	vec_left = XMVector3TransformCoord(DEFAULT_LEFT_VECTOR, vecRotationMatrix);
	vec_right = XMVector3TransformCoord(DEFAULT_RIGHT_VECTOR, vecRotationMatrix);


}


const XMVECTOR& Wall::GetPositionVector() const
{
	return posVector;
}

const XMFLOAT3& Wall::GetPositionFloat3() const
{
	return pos;
}

const XMVECTOR& Wall::GetRotationVector() const
{
	return rotVector;
}

const XMFLOAT3& Wall::GetRotationFloat3() const
{
	return rot;
}

void Wall::SetPosition(const XMVECTOR& pos)
{
	XMStoreFloat3(&this->pos, pos);
	posVector = pos;
	UpdateWorldMatrix();
}

void Wall::SetPosition(const XMFLOAT3& pos)
{
	this->pos = pos;
	posVector = XMLoadFloat3(&this->pos);
	UpdateWorldMatrix();
}

void Wall::SetPosition(float x, float y, float z)
{
	pos = XMFLOAT3(x, y, z);
	posVector = XMLoadFloat3(&pos);
	UpdateWorldMatrix();
}

void Wall::AdjustPosition(const XMVECTOR& pos)
{
	posVector += pos;
	XMStoreFloat3(&this->pos, posVector);
	UpdateWorldMatrix();
}

void Wall::AdjustPosition(const XMFLOAT3& pos)
{
	this->pos.x += pos.y;
	this->pos.y += pos.y;
	this->pos.z += pos.z;
	posVector = XMLoadFloat3(&this->pos);
	UpdateWorldMatrix();
}

void Wall::AdjustPosition(float x, float y, float z)
{
	this->pos.x += x;
	this->pos.y += y;
	this->pos.z += z;
	this->posVector = XMLoadFloat3(&this->pos);
	this->UpdateWorldMatrix();
}

void Wall::SetRotation(const XMVECTOR& rot)
{
	rotVector = rot;
	XMStoreFloat3(&this->rot, rot);
	UpdateWorldMatrix();
}

void Wall::SetRotation(const XMFLOAT3& rot)
{
	this->rot = rot;
	this->rotVector = XMLoadFloat3(&this->rot);
	UpdateWorldMatrix();
}

void Wall::SetRotation(float x, float y, float z)
{
	this->rot = XMFLOAT3(x, y, z);
	this->rotVector = XMLoadFloat3(&this->rot);
	UpdateWorldMatrix();
}

void Wall::AdjustRotation(const XMVECTOR& rot)
{
	this->rotVector += rot;
	XMStoreFloat3(&this->rot, this->rotVector);
	UpdateWorldMatrix();
}

void Wall::AdjustRotation(const XMFLOAT3& rot)
{
	this->rot.x += rot.x;
	this->rot.y += rot.y;
	this->rot.z += rot.z;
	rotVector = XMLoadFloat3(&this->rot);
	UpdateWorldMatrix();
}

void Wall::AdjustRotation(float x, float y, float z)
{
	this->rot.x += x;
	this->rot.y += y;
	this->rot.z += z;
	this->rotVector = XMLoadFloat3(&this->rot);
	UpdateWorldMatrix();
}

const XMVECTOR& Wall::GetForwardVector()
{
	return this->vec_forward;
}

const XMVECTOR& Wall::GetRightVector()
{
	return this->vec_right;
}

const XMVECTOR& Wall::GetBackwardVector()
{
	return this->vec_backward;
}

const XMVECTOR& Wall::GetLeftVector()
{
	return this->vec_left;
}


