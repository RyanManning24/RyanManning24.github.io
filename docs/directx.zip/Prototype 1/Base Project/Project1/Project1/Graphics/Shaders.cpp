#include "Shaders.h"


VertexShader::~VertexShader()
{
	if (shader)
	{
		shader->Release();
		shader = 0;
	}
	if (shader_buffer)
	{
		shader_buffer->Release();
		shader_buffer = 0;
	}
	if (inputLayout)
	{
		inputLayout->Release();
		inputLayout = 0;
	}
	PixelShader ps;
	if (ps.Pshader)
	{
		ps.Pshader->Release();
		ps.Pshader = 0;
	}
	if (ps.Pshader_buffer)
	{
		ps.Pshader_buffer->Release();
		ps.Pshader_buffer = 0;
	}

}

bool VertexShader::Init(ID3D11Device* device, std::wstring shaderpath, D3D11_INPUT_ELEMENT_DESC* layoutDesc, UINT numElements)
{
	HRESULT hr = D3DReadFileToBlob(shaderpath.c_str(), &shader_buffer);
	
	if (FAILED(hr))
	{
		std::wstring errorMsg = L"Failed to load shader: ";
		errorMsg += shaderpath;
		ErrorLogger::Log(hr, errorMsg);
		return false;
	}

	hr = device->CreateVertexShader(this->shader_buffer->GetBufferPointer(), this->shader_buffer->GetBufferSize(), NULL, &this->shader);

	if (FAILED(hr))
	{
		std::wstring errorMsg = L"Failed to create vertex shader";
		errorMsg += shaderpath;
		ErrorLogger::Log(hr, errorMsg);
		return false;
	}
	
	hr = device->CreateInputLayout(layoutDesc, numElements, this->shader_buffer->GetBufferPointer(), this->shader_buffer->GetBufferSize(), &inputLayout);
	if (FAILED(hr))
	{
		ErrorLogger::Log(hr, "Failed to create input layout");
		return false;
	}


	return true;

}

ID3D11VertexShader* VertexShader::getShader()
{
	return shader;
}

ID3D10Blob* VertexShader::GetBuffer()
{
	return shader_buffer;
}

ID3D11InputLayout* VertexShader::GetInputLayout()
{
	return inputLayout;
}

bool PixelShader::Initialize(ID3D11Device* device, std::wstring shaderpath)
{
	HRESULT hr = D3DReadFileToBlob(shaderpath.c_str(), &Pshader_buffer);
	if (FAILED(hr))
	{
		std::wstring errorMsg = L"Failed to load shader: ";
		errorMsg += shaderpath;
		ErrorLogger::Log(hr, errorMsg);
		return false;
	}

	hr = device->CreatePixelShader(Pshader_buffer->GetBufferPointer(), Pshader_buffer->GetBufferSize(), NULL, &Pshader);
	if (FAILED(hr))
	{
		std::wstring errorMsg = L"Failed to create pixel shader";
		errorMsg += shaderpath;
		ErrorLogger::Log(hr, errorMsg);
		return false;
	}

	return true;
}

ID3D11PixelShader* PixelShader::GetShader()
{
	return Pshader;
}

ID3D10Blob* PixelShader::GetBuffer()
{
	return Pshader_buffer;
}