#pragma once
#include "../ErrorLogger.h"

#include <d3d11.h>
#include <D3Dcompiler.h>
#pragma comment (lib, "DirectXTK.lib")




class VertexShader
{
public:
	~VertexShader();
	bool Init(ID3D11Device* device, std::wstring shaderpath, D3D11_INPUT_ELEMENT_DESC* layoutDesc,UINT numElements);
	ID3D11VertexShader* getShader();
	ID3D10Blob* GetBuffer();
	ID3D11InputLayout* GetInputLayout();

private:
	ID3D11VertexShader* shader = nullptr;
	ID3D10Blob* shader_buffer = nullptr;
	ID3D11InputLayout* inputLayout;
};

class PixelShader
{
public:
	bool Initialize(ID3D11Device* device, std::wstring shaderpath);
	ID3D11PixelShader* GetShader();
	ID3D10Blob* GetBuffer();

	ID3D11PixelShader* Pshader = nullptr;
	ID3D10Blob* Pshader_buffer = nullptr;

};