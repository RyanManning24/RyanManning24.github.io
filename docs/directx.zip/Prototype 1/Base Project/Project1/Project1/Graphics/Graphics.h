#pragma once
#include <d3d11.h>
#include "Shaders.h"
#include "../ErrorLogger.h"
#include <SpriteBatch.h>
#include <SpriteFont.h>
#include <WICTextureLoader.h>
#include "Camera.h"
#include "../Wall.h"



class Graphics
{
public:
	~Graphics();
	bool Init(HWND hwnd, int width, int height);
	void RenderFrame();

	Camera camera;
	Wall Cube [17];
	Wall floor [5];
	
	

private:
	bool InitDirectX(HWND hwnd);
	bool InitShaders();
	bool InitScene();


	ID3D11Device* device;
	ID3D11DeviceContext* deviceContext;
	IDXGISwapChain* swapChain;
	ID3D11RenderTargetView* renderTargetView;
	ID3D11Texture2D* backBuffer;
	

	VertexShader vertexShader;
	PixelShader pixelshader;

	ConstantBuffer<CB_VS_vertexshader> constantBuffer;

	

	ID3D11DepthStencilView* depthStencilView;
	ID3D11Texture2D* depthStencilBuffer;
	ID3D11DepthStencilState* depthStencilState;

	ID3D11RasterizerState* rasterizerState;

	std::unique_ptr<DirectX::SpriteBatch> spriteBatch;
	std::unique_ptr <DirectX::SpriteFont> spriteFont;

	ID3D11SamplerState* samplerState;	
	ID3D11ShaderResourceView* myTexture;
	ID3D11ShaderResourceView* floorTexture;

	int windowWidth = 0;
	int windowHeight = 0;

	

};