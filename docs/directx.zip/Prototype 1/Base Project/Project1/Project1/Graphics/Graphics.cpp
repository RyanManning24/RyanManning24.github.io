#include "Graphics.h"

Graphics::~Graphics()
{
	if (device)
	{
		device->Release();
		device = 0;
	}
	if (deviceContext)
	{
		deviceContext->Release();
		deviceContext = 0;
	}
	if (swapChain)
	{
		swapChain->Release();
		swapChain = 0;
	}
	if (renderTargetView)
	{
		renderTargetView->Release();
		renderTargetView = 0;
	}
	if (backBuffer)
	{
		backBuffer->Release();
		backBuffer = 0;
	}
	if (rasterizerState)
	{
		rasterizerState->Release();
		rasterizerState = 0;
	}
	if (depthStencilBuffer)
	{
		depthStencilBuffer->Release();
		depthStencilBuffer = 0;
	}
	if (depthStencilView)
	{
		depthStencilView->Release();
		depthStencilView = 0;
	}
	if (depthStencilState)
	{
		depthStencilState->Release();
		depthStencilState = 0;
	}
	if (samplerState)
	{
		samplerState->Release();
		samplerState = 0;
	}
	if (myTexture)
	{
		myTexture->Release();
		myTexture = 0;
	}
	if (floorTexture)
	{
		floorTexture->Release();
		floorTexture = 0;
	}


	
	
}

bool Graphics::Init(HWND hwnd, int width, int height)
{

	windowWidth = width;
	windowHeight = height;

	if (!InitDirectX(hwnd))
	{
		return false;
	}
	if (!InitShaders())
	{
		return false;
	}
	if (!InitScene())
	{
		return false;
	}

	return true;
}

bool Graphics::InitDirectX(HWND hwnd)
{
	DXGI_SWAP_CHAIN_DESC scd;
	ZeroMemory(&scd, sizeof(DXGI_SWAP_CHAIN_DESC));

	scd.BufferDesc.Width = windowWidth;
	scd.BufferDesc.Height = windowHeight;
	scd.BufferDesc.RefreshRate.Numerator = 60;
	scd.BufferDesc.RefreshRate.Denominator = 1;
	scd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
	scd.BufferDesc.ScanlineOrdering = DXGI_MODE_SCANLINE_ORDER_UNSPECIFIED;
	scd.BufferDesc.Scaling = DXGI_MODE_SCALING_UNSPECIFIED;
	scd.SampleDesc.Count = 1;
	scd.SampleDesc.Quality = 0;
	scd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
	scd.BufferCount = 1;
	scd.OutputWindow = hwnd;
	scd.Windowed = TRUE;
	scd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;
	scd.Flags = DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH;

	HRESULT hr;
	hr = D3D11CreateDeviceAndSwapChain(NULL,
		D3D_DRIVER_TYPE_HARDWARE,
		NULL,
		NULL,
		NULL,
		0,
		D3D11_SDK_VERSION,
		&scd,
		&swapChain,
		&device,
		NULL,
		&deviceContext);
	
	if (FAILED(hr))
	{
		ErrorLogger::Log(hr, "FAILED to create device and swapchain");
		return false;
	}

	hr = this->swapChain->GetBuffer(0, __uuidof(ID3D11Texture2D), reinterpret_cast<void**>(&backBuffer));
	if(FAILED(hr))
	{
		ErrorLogger::Log(hr, "GetBuffer Failed");
		return false;
	}

	hr = this->device->CreateRenderTargetView(backBuffer, NULL, &renderTargetView);
	if (FAILED(hr))
	{
		ErrorLogger::Log(hr, "Failed to create render target view");
		return false;
	}

	D3D11_TEXTURE2D_DESC depthStencilDesc;
	depthStencilDesc.Width = windowWidth;
	depthStencilDesc.Height = windowHeight;
	depthStencilDesc.MipLevels = 1;
	depthStencilDesc.ArraySize = 1;
	depthStencilDesc.Format = DXGI_FORMAT_D24_UNORM_S8_UINT;
	depthStencilDesc.SampleDesc.Count = 1;
	depthStencilDesc.SampleDesc.Quality = 0;
	depthStencilDesc.Usage = D3D11_USAGE_DEFAULT;
	depthStencilDesc.BindFlags = D3D11_BIND_DEPTH_STENCIL;
	depthStencilDesc.CPUAccessFlags = 0; 
	depthStencilDesc.MiscFlags = 0;

	hr = device->CreateTexture2D(&depthStencilDesc, NULL, &depthStencilBuffer);
	if (FAILED(hr))
	{
		ErrorLogger::Log(hr, "Failed to create depth stencil buffer");
		return false;
	}

	hr = device->CreateDepthStencilView(depthStencilBuffer, NULL, &depthStencilView);
	if (FAILED(hr))
	{
		ErrorLogger::Log(hr, "Failed to create depth stencil");
		return false;
	}


	this->deviceContext->OMSetRenderTargets(1, &renderTargetView, depthStencilView);

	D3D11_DEPTH_STENCIL_DESC depthstencildesc;
	ZeroMemory(&depthstencildesc, sizeof(D3D11_DEPTH_STENCIL_DESC));

	depthstencildesc.DepthEnable = true;
	depthstencildesc.DepthWriteMask = D3D11_DEPTH_WRITE_MASK::D3D11_DEPTH_WRITE_MASK_ALL;
	depthstencildesc.DepthFunc = D3D11_COMPARISON_FUNC::D3D11_COMPARISON_LESS_EQUAL;

	hr = device->CreateDepthStencilState(&depthstencildesc, &depthStencilState);
	if (FAILED(hr))
	{
		ErrorLogger::Log(hr, "Failed to create depth stencil state");
		return false;
	}

	D3D11_VIEWPORT viewport;
	ZeroMemory(&viewport, sizeof(D3D11_VIEWPORT));

	viewport.TopLeftX = 0;
	viewport.TopLeftY = 0;
	viewport.Width = windowWidth;
	viewport.Height = windowHeight;
	viewport.MinDepth = 0.0f;
	viewport.MaxDepth = 1.0f;

	deviceContext->RSSetViewports(1, &viewport);

	D3D11_RASTERIZER_DESC rasterizerDesc;
	ZeroMemory(&rasterizerDesc, sizeof(D3D11_RASTERIZER_DESC));

	rasterizerDesc.FillMode = D3D11_FILL_MODE::D3D11_FILL_SOLID;
	rasterizerDesc.CullMode = D3D11_CULL_MODE::D3D11_CULL_BACK;
	hr = device->CreateRasterizerState(&rasterizerDesc, &rasterizerState);
	if (FAILED(hr))
	{
		ErrorLogger::Log(hr, "Failed to create rasterizer state.");
		return false;
	}

	spriteBatch = std::make_unique<DirectX::SpriteBatch>(deviceContext);
	spriteFont = std::make_unique<DirectX::SpriteFont>(device, L"Data\\Fonts\\Calibri.spritefont");

	D3D11_SAMPLER_DESC sampDesc;
	ZeroMemory(&sampDesc, sizeof(sampDesc));
	sampDesc.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
	sampDesc.AddressU = D3D11_TEXTURE_ADDRESS_WRAP;
	sampDesc.AddressV = D3D11_TEXTURE_ADDRESS_WRAP;
	sampDesc.AddressW = D3D11_TEXTURE_ADDRESS_WRAP;
	sampDesc.ComparisonFunc = D3D11_COMPARISON_NEVER;
	sampDesc.MinLOD = 0;
	sampDesc.MaxLOD = D3D11_FLOAT32_MAX;

	hr = device->CreateSamplerState(&sampDesc, &samplerState);

	if (FAILED(hr))
	{
		ErrorLogger::Log(hr, "Failed to create sampler state");
		return false;
	}


	return true;
}

void Graphics::RenderFrame()
{
	float bgcolor[] = {0.0f,0.0f,0.0f,1.0f};
	deviceContext->ClearRenderTargetView(renderTargetView, bgcolor);
	deviceContext->ClearDepthStencilView(depthStencilView, D3D11_CLEAR_DEPTH | D3D11_CLEAR_DEPTH, 1.0f,0);

	deviceContext->IASetInputLayout(vertexShader.GetInputLayout());
	deviceContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY::D3D10_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
	deviceContext->RSSetState(rasterizerState);
	deviceContext->OMSetDepthStencilState(depthStencilState, 0);

	deviceContext->PSSetSamplers(0, 1, &samplerState);

	deviceContext->VSSetShader(vertexShader.getShader(), NULL, 0);
	deviceContext->PSSetShader(pixelshader.GetShader(), NULL, 0);

	UINT offset = 0;

	//update constant buffer
	XMMATRIX world = XMMatrixIdentity();

	for(int i = 0; i < 17; i++)
	{
		Cube[i].Draw(camera.GetViewMatrix() * camera.GetProjectionMatix());
	}

	for (int i = 0; i < 5; i++)
	{
		floor[i].Draw(camera.GetViewMatrix() * camera.GetProjectionMatix());
	}
	


	//Draw Text
	spriteBatch->Begin();
	spriteFont->DrawString(spriteBatch.get(), L"Level 1", DirectX::XMFLOAT2(0, 0), DirectX::Colors::White, 0.0f, DirectX::XMFLOAT2(0.0f,0.0f), DirectX::XMFLOAT2(1.0f, 1.0f));
	spriteBatch->End();

	this->swapChain->Present(0, NULL);
}

bool Graphics::InitShaders()
{
	std::wstring shaderfolder;
#pragma region DetermineShaderPath
	if (IsDebuggerPresent() == TRUE)
	{
#ifdef _DEBUG
	#ifdef _WIN64
		shaderfolder = L"..\\x64\\Debug\\";
	#else //x86 (Win32)
		shaderfolder = L"..\\Debug\\";
	#endif // _WIN64
	#else
	#ifdef _WIN64
		shaderfolder = L"..\\x64\\Release\\";
	#else
		shaderfolder = L"..\\Release\\";
	#endif 
#endif 

	}

	D3D11_INPUT_ELEMENT_DESC layout[] =
	{
		{"POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 0, D3D11_INPUT_CLASSIFICATION::D3D11_INPUT_PER_VERTEX_DATA, 0},
		{"TEXCOORD", 0, DXGI_FORMAT::DXGI_FORMAT_R32G32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_CLASSIFICATION::D3D11_INPUT_PER_VERTEX_DATA, 0	},
	};

	UINT numElements = ARRAYSIZE(layout);


	if (!vertexShader.Init(device, shaderfolder + L"vertexshader.cso", layout, numElements))
	{
		return false;
	}

	if (!pixelshader.Initialize(device, shaderfolder + L"pixelshader.cso"))
	{
		return false;
	}



	return true;
}

bool Graphics::InitScene()
{

	//load texture
	HRESULT hr = DirectX::CreateWICTextureFromFile(device, L"Data\\Textures\\BrickWall.png", nullptr, &myTexture);
	if (FAILED(hr))
	{
		ErrorLogger::Log(hr, "Failed to create wic texture from file");
		return false;
	}

	hr = DirectX::CreateWICTextureFromFile(device, L"Data\\Textures\\floor.jpg", nullptr, &floorTexture);
	if (FAILED(hr))
	{
		ErrorLogger::Log(hr, "Failed to create wic texture from file");
		return false;
	}


	hr = constantBuffer.Initialize(device, deviceContext);
	if (FAILED(hr))
	{
		ErrorLogger::Log(hr, "Failed to init constant buffer");
		return false;
	}

	for (int i = 0; i < 17; i++)
	{
		Cube[i].Init(device, deviceContext, myTexture, constantBuffer);
	}


	for (int i = 0; i < 5; i++)
	{
		floor[i].Init(device, deviceContext, floorTexture, constantBuffer);
	}



	camera.SetPosition(3.0f, 0, -10.0f);
	camera.SetProjectionValues(90.0f, static_cast<float>(windowWidth)/ static_cast<float>(windowHeight), 0.1f, 1000.0f);


	return true;
}
