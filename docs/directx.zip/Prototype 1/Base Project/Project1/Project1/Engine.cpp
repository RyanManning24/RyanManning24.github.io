#include"Engine.h"

bool Engine::Initialize(HINSTANCE hInstance, std::string window_title, std::string window_class, int width, int height)
{
	timer.Start();

	if (!this->render_window.Initialize(this, hInstance, window_title, window_class, width, height))
	{
		return false;
	}
	
	if(!gfx.Init(this->render_window.GetHWND(),width,height))
	{
		return false;
	}

	//Walls

	gfx.Cube[0].SetPosition(0, 0, -4);
	gfx.Cube[1].SetPosition(0, 0, -16);

	gfx.Cube[3].SetRotation(0, 190, 0);
	gfx.Cube[3].SetPosition(10,0,-6);

	gfx.Cube[4].SetPosition(-20, 0, -4);
	gfx.Cube[5].SetPosition(-20, 0, -16);

	gfx.Cube[8].SetRotation(0,80,0);
	gfx.Cube[8].SetPosition(-42.5f,0,-5);

	gfx.Cube[9].SetRotation(0,80,0);
	gfx.Cube[9].SetPosition(-40.25f, 0, -24.5f);

	
	gfx.Cube[10].SetPosition(-35,-1,-33);

	gfx.Cube[11].SetRotation(0,80,0);
	gfx.Cube[11].SetPosition(-27,-1,-27);

	gfx.Cube[12].SetRotation(0,80,0);
	gfx.Cube[12].SetPosition(-30,-1,7);

	gfx.Cube[13].SetRotation(0,80,0);
	gfx.Cube[13].SetPosition(-44,-1,10);

	gfx.Cube[14].SetPosition(-41, -1, 15);

	//roof
	gfx.Cube[2].SetRotation(190, 0, 0);
	gfx.Cube[2].SetPosition(0, 5, -10);

	gfx.Cube[6].SetRotation(190, 0, 0);
	gfx.Cube[6].SetPosition(-20,5,-10);
	
	gfx.Cube[7].SetRotation(190, 80, 0);
	gfx.Cube[7].SetPosition(-35, 5, -10);

	gfx.Cube[15].SetRotation(190, 80, 0);
	gfx.Cube[15].SetPosition(-37,5,5);

	gfx.Cube[16].SetRotation(190,80,0);
	gfx.Cube[16].SetPosition(-34,5,-23);



	//floor
	gfx.floor[0].SetRotation(190, 0, 0);
	gfx.floor[0].SetPosition(0, -5, -10);

	gfx.floor[1].SetRotation(190, 0, 0);
	gfx.floor[1].SetPosition(-20, -5, -10);
		
	gfx.floor[2].SetRotation(190, 80, 0);
	gfx.floor[2].SetPosition(-35, -5, -10);

	gfx.floor[3].SetRotation(190, 80, 0);
	gfx.floor[3].SetPosition(-33, -5, -30);

	gfx.floor[4].SetRotation(190, 80, 0);
	gfx.floor[4].SetPosition(-37.5f, -5.0f, 9);


	return true;
}

bool Engine::ProcessMessages()
{
	return this->render_window.ProcessMessages();
}

void Engine::Update()
{
	float dt = timer.GetMilisecondsElapsed();
	timer.Restart();

	while (!keyboard.CharBufferIsEmpty())
	{
		unsigned char ch = keyboard.ReadChar();
	}

	while (!keyboard.KeyBufferIsEmpty())
	{
		
		KeyboardEvent kbe = keyboard.ReadKey();
		unsigned char keycode = kbe.GetKeyCode();
	
	}

	while (!mouse.EventBufferIsEmpty())
	{
		MouseEvent me = mouse.ReadEvent();
		if (me.GetType() == MouseEvent::EventType::RAW_MOVE)
		{
			this->gfx.camera.AdjustRotation((float)me.GetPosY() * 0.01f * dt, (float)me.GetPosX() * 0.01f * dt, 0);
		}
		

		
	}

	const float cameraSpeed = 0.01f;
	

	if (keyboard.KeyIsPressed('W'))
	{
		gfx.camera.AdjustPosition(gfx.camera.GetForwardVector() * cameraSpeed * dt);
	}
	if (keyboard.KeyIsPressed('S'))
	{
		gfx.camera.AdjustPosition(gfx.camera.GetBackwardVector() * cameraSpeed * dt);
	}
	if (keyboard.KeyIsPressed('A'))
	{
		gfx.camera.AdjustPosition(gfx.camera.GetLeftVector() * cameraSpeed * dt);
	}
	if (keyboard.KeyIsPressed('D'))
	{
		gfx.camera.AdjustPosition(gfx.camera.GetRightVector() * cameraSpeed * dt);
	}
	if (keyboard.KeyIsPressed(VK_SPACE))
	{
		gfx.camera.AdjustPosition(0.0f, cameraSpeed * dt, 0.0f);
	}
	if (keyboard.KeyIsPressed('Z'))
	{
		gfx.camera.AdjustPosition(0.0f, -cameraSpeed * dt, 0.0f);
	}

	


}

void Engine::RenderFrame()
{
	this->gfx.RenderFrame();
}

bool Engine::BoundingBox(XMVECTOR& firstObjMin, XMVECTOR& firstObjMax, XMMATRIX& firstObjWorldSpace, XMVECTOR& secondObjMin, XMVECTOR& secondObjMax, XMMATRIX& secondObjWorldSpace)
{
	if (XMVectorGetX(firstObjMax) > XMVectorGetX(secondObjMin))
	{
		if (XMVectorGetX(firstObjMin) < XMVectorGetX(secondObjMax))
		{
			if (XMVectorGetY(firstObjMax) > XMVectorGetY(secondObjMin))
			{
				if (XMVectorGetY(firstObjMin) < XMVectorGetY(secondObjMax))
				{
					if (XMVectorGetZ(firstObjMax) > XMVectorGetZ(secondObjMin))
					{
						if (XMVectorGetZ(firstObjMin) < XMVectorGetZ(secondObjMax))
						{
							return true;
						}
					}
				}
			}
		}
	}


	return false;
}
